Library to help download images from Google Image Search for various machine learning and image classification tasks.This library uses web scrapping using selenium to download images from google image search.But the way this library is different from other similar ones is that it utilizes headless chrome to perform this activity,this means that it does not need an UI shell to execute and that it can be used in server environments as well.


